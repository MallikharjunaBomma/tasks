const fs = require('fs')  // load fs module
const inputFile = '/uploads/input.txt'  //input file path
const outputFile = '/myfiles/output.txt'  //output file path


//Read data from Input file
fs.readFile(inputFile, 'utf8', (error, data) => {
    if (error) {
        throw error
    }
   // Process Data
    const rows = data.split("\n\n");  //To process each test case, convert the string to an array.
    for(let row=0; row < rows.length; row++){
        const rowData = rows[row].split('\n');  //To handle row data, convert a string to an array.
        const testNo = rowData[0];
        const numOfTasks = +rowData[1];
        const initialStart = rowData[numOfTasks + 2].split(',');
        const tasks = prepareTest(numOfTasks, rowData)  // build a test object from the input information.
        
        const executedTasks = {};
        processTest(initialStart, tasks,executedTasks) //run the test
        const output =  testNo + Object.keys(executedTasks).join(',') +'\n'// prepare output string
        //write data to file
        fs.appendFileSync(outputFile, output, 'utf8', error => {
                        if (error) throw error;
                    });

    }
})

function prepareTest(numOfTasks, rowData) {
    const test = {}
    //loop through the tasks to prepare an object
    for (let i = 0; i < numOfTasks; i++) {
        let taskData = rowData[i + 2].split(';')
        let input = taskData[0].split(',')
        let output = taskData[1].split(',')
        for (let j = 0; j < input.length; j++) {
            test[input[j]] = {
                task: i,
                inputs: input,
                outputs : output
            };
        }
    }
    return test
}

//process test cases
function processTest(initialStart, tasks, executedTasks) {
     //Begin the tasks with initial data change and loop through them.
     for (let i = 0; i < initialStart.length; i++) {
        const input = initialStart[i]
        
        if (tasks[input] ) {
            const task = tasks[input].task
            const taskInputs = tasks[input].inputs
            const taskOutputs = tasks[input].outputs
            // make an object with completed tasks. 
            if (!(executedTasks[task])) {
                executedTasks[task] = taskOutputs;
                processTest(taskOutputs, tasks, executedTasks)
            }
        }
        }
}